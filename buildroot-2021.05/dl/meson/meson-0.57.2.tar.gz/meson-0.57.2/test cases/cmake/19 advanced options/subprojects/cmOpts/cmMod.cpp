#include "cmMod.hpp"

using namespace std;

#if __cplusplus < 201402L
#error "At least C++14 is required"
#endif

#ifndef MESON_GLOBAL_FLAG
#error "MESON_GLOBAL_FLAG was not set"
#endif

#ifndef MESON_SPECIAL_FLAG1
#error "MESON_SPECIAL_FLAG1 was not set"
#endif

#ifndef MESON_SPECIAL_FLAG2
#error "MESON_SPECIAL_FLAG2 was not set"
#endif

cmModClass::cmModClass(string foo) {
  str = foo + " World";
}

string cmModClass::getStr() const {
  return str;
}

int cmModClass::getInt() const {
  return MESON_MAGIC_INT;
}
