.. currentmodule:: freetype

Size Metrics
============
.. autoclass:: SizeMetrics
   :members:
