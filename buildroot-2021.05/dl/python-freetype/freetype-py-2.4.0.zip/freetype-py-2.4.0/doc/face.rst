.. currentmodule:: freetype

Face                                                                           
====
.. autoclass:: Face
   :members:
