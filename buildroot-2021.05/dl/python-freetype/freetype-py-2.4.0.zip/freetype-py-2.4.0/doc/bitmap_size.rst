.. currentmodule:: freetype

Bitmap size
===========
.. autoclass:: BitmapSize
   :members:
