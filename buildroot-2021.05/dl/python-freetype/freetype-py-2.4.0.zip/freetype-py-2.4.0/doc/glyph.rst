.. currentmodule:: freetype

Glyph
=====
.. autoclass:: Glyph
   :members:
