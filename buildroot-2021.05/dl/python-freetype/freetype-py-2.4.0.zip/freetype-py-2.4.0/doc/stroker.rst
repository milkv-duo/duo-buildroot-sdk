.. currentmodule:: freetype

Stroker
=======
.. autoclass:: Stroker
   :members:
