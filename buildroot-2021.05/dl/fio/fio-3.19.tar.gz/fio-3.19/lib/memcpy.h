#ifndef FIO_MEMCPY_H
#define FIO_MEMCPY_H

int fio_memcpy_test(const char *type);

#endif
