#!/bin/sh

pkg install -y python ndk-sysroot clang make \
    libjpeg-turbo

